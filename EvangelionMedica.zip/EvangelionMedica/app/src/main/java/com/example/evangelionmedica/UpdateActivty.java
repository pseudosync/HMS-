package com.example.evangelionmedica;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class UpdateActivty extends AppCompatActivity {
    TextView viewer;
    ArrayList<PatientObject> Patients = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_activty);

        populateListView();

    }//OnCreate

    private void populateListView(){

        try {
            Patients = PatientModel.getRows();
        }catch (Exception e){
            Log.e("GET PATIENT RECORD", "Error: " + e.toString());
        }

        ArrayAdapter<PatientObject> adapter = new MyPatientAdapter();
        ListView list = findViewById(R.id.ListViewPatients);
        list.setAdapter(adapter);
    }

    private class MyPatientAdapter extends ArrayAdapter<PatientObject>{
        public MyPatientAdapter(){
            super(UpdateActivty.this, R.layout.patient_update_layout, Patients);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View itemView = convertView;
            if (itemView == null){
                itemView = getLayoutInflater().inflate(R.layout.patient_update_layout, parent, false);
            }
            //populate ListView

            //find patient position to work with
            PatientObject currPat = Patients.get(position);

            //Patient Number
            TextView PatientNo = itemView.findViewById(R.id.tvPatientNo);
            PatientNo.setText(Integer.toString(currPat.getPatientNo()));

            //Patient Name
            final TextView PatientName = itemView.findViewById(R.id.txtUpdatePatientName);
            PatientName.setText(currPat.getPatientName());

            //Patient Address
            final TextView PatientAddress = itemView.findViewById(R.id.txtUpdatePatientAddress);
            PatientAddress.setText(currPat.getPatientAddress());

            //Patient Doctor
            final TextView PatientDoctor = itemView.findViewById(R.id.txtUpdatePatientDoctor);
            PatientDoctor.setText(currPat.getPatientDoctor());

            //Patient Phone Number
            final TextView PatientPhoneNumber = itemView.findViewById(R.id.txtUpdatePhoneNumber);
            PatientPhoneNumber.setText(Integer.toString(currPat.getPatientPhoneNo()));

            //Patient Email Address
            final TextView PatientEmailAddress = itemView.findViewById(R.id.txtUpdateEmailAddress);
            PatientEmailAddress.setText(currPat.getPatientEmailAddress());

            //Patient In Patient Time
            final TextView InpatientTime = itemView.findViewById(R.id.updateInPatientTime);
            InpatientTime.setText(Integer.toString(currPat.getInpatientTime()));

            //Patient In Patient Date
            final TextView InpatientDate = itemView.findViewById(R.id.updateInPatientDate);
            InpatientDate.setText(Integer.toString(currPat.getInpatientDate()));

            //Patient Out Patient Time
            final TextView OutpatientTime = itemView.findViewById(R.id.updateOutPatientTime);
            OutpatientTime.setText(Integer.toString(currPat.getOutPatientTime()));

            //Patient Out Patient Date
            final TextView OutpatientDate = itemView.findViewById(R.id.updateOutPatientDate);
            OutpatientDate.setText(Integer.toString(currPat.getOutPatientDate()));

            //Update Button>> START
            Button btnUpdate = itemView.findViewById(R.id.btnUpdateRecord);
            btnUpdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    //check if all fields have a value
                    if (PatientNo.getText().toString().isEmpty() ||
                            PatientName.getText().toString().isEmpty() ||
                            PatientAddress.getText().toString().isEmpty() ||
                            PatientDoctor.getText().toString().isEmpty() ||
                            PatientPhoneNumber.getText().toString().isEmpty() ||
                            PatientEmailAddress.getText().toString().isEmpty() ||
                            InpatientTime.getText().toString().isEmpty() ||
                            InpatientDate.getText().toString().isEmpty() ||
                            OutpatientTime.getText().toString().isEmpty() ||
                            OutpatientDate.getText().toString().isEmpty()
                    ){
                        if (PatientNo.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient ID is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientNo.requestFocus();
                        }else if (PatientName.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Name is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientName.requestFocus();
                        }else if (PatientAddress.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Address is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientAddress.requestFocus();
                        }else if (PatientDoctor.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Doctor is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientDoctor.requestFocus();
                        }else if (PatientPhoneNumber.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Phone Number is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientPhoneNumber.requestFocus();
                        }else if (PatientEmailAddress.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Email Address is REQUIRED!", Toast.LENGTH_LONG).show();
                            PatientEmailAddress.requestFocus();
                        }else if (InpatientTime.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Time of Admission/Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                            InpatientTime.requestFocus();
                        }else if (InpatientDate.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Date of Admission/Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                            InpatientDate.requestFocus();
                        }else if (OutpatientTime.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Time of Discharge/End of Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                            OutpatientTime.requestFocus();
                        }else if (OutpatientDate.getText().toString().isEmpty()){
                            Toast.makeText(getApplicationContext(),
                                    "Date of Discharge/End of Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                            OutpatientDate.requestFocus();
                        }
                    }else{
                        int PatNo = Integer.parseInt(PatientNo.getText().toString());
                        String PatName = PatientName.getText().toString();
                        String PatAddress = PatientAddress.getText().toString();
                        String PatDoctor = PatientDoctor.getText().toString();
                        int PatPhoneNo = Integer.parseInt(PatientPhoneNumber.getText().toString());
                        String PatEmailAddress = PatientEmailAddress.getText().toString();
                        int InpaTime = Integer.parseInt(InpatientTime.getText().toString());
                        int InpaDate = Integer.parseInt(InpatientDate.getText().toString());
                        int OutPaTime = Integer.parseInt(OutpatientTime.getText().toString());
                        int OutPaDate = Integer.parseInt(OutpatientDate.getText().toString());

                        System.out.println("PatientNo = " + PatNo +
                                ", PatientName = " + PatName +
                                ", PatientAddress = " + PatAddress +
                                ", Patient Doctor = " + PatDoctor +
                                ", PatientPhoneNumber = " + PatPhoneNo +
                                ", PatientEmailAddress = " + PatEmailAddress +
                                ", InpatientTime = " + InpaTime +
                                ", InpatientDate = " + InpaDate +
                                ", OutpatientTime = " + OutPaTime +
                                ", OutpatientDate = " + OutPaDate);

                       if (PatientModel.updatePatientRecord (PatNo, PatName, PatAddress, PatDoctor, PatPhoneNo, PatEmailAddress,
                                InpaTime, InpaDate, OutPaTime, OutPaDate)){
                            Toast.makeText(getApplicationContext(),
                                    "Patient Record Successfully Updated", Toast.LENGTH_LONG).show();
                        }

                    }

                }
            });
            //Update Button>> END

            //Delete Button >> START
            Button btnDelete = itemView.findViewById(R.id.btnDeleteRecord);
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int PatNo = Integer.parseInt(PatientNo.getText().toString());

                    if (PatientModel.deleteStudentRecord(PatNo)){
                        Toast.makeText(getApplicationContext(),
                                "Patient Record Successfully Deleted!", Toast.LENGTH_SHORT).show();
                        //update listview
                        populateListView();
                    }
                }
            });
            //Delete Button >> END

            return itemView;
        }
    }
}//public class