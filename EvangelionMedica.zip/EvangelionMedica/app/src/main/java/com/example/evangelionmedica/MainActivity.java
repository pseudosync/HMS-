package com.example.evangelionmedica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button insertButton, updateButton;
    PatientModel patMod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        patMod = new PatientModel(getApplicationContext());

        insertButton = findViewById(R.id.btnInsert);
        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent insertActIntent = new Intent(MainActivity.this, Activity_Insert.class);
                MainActivity.this.startActivity(insertActIntent);
            }
        });

        updateButton = findViewById(R.id.btnUpdateRecord);
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent updateActIntent = new Intent(MainActivity.this, UpdateActivty.class);
                MainActivity.this.startActivity(updateActIntent);
            }
        });

    }
}