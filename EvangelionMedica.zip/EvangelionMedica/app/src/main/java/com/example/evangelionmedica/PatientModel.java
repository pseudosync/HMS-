package com.example.evangelionmedica;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class PatientModel {

    static final String DATABASE_NAME = "EvangelionMedico.db";
    static final String TABLE_NAME = "Patient";
    static final int DATABASE_VERSION = 2;

    static final String CREATE_Patient_Table = "" +
            "CREATE TABLE " + TABLE_NAME + " (" +
            "PatientNumber INTEGER PRIMARY KEY," +
            "PatientName TEXT," +
            "PatientAddress TEXT," +
            "PatientDoctor TEXT," +
            "PatientPhoneNumber INTEGER," +
            "PatientEmailAddress TEXT," +
            "AdmissionConsultationTime INTEGER," +
            "AdmissionConsultationDate INTEGER," +
            "DischargeEndConsultationTime INTEGER," +
            "DischargeEndConsultationDate INTEGER" +
            ")";

    public static SQLiteDatabase db;

    private final Context context;

    private static EvangelionMedicaDatabaseHelper dbHelper;

    public PatientModel(Context cont){
        context = cont;
        dbHelper = new EvangelionMedicaDatabaseHelper (context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static boolean insertPatientRecord(
            int PatNo, String PatName, String PatAddress, String PatDoctor, int PatPhoneNo, String PatEmailAddress,
            int InpaTime, int InpaDate, int OutPaTime, int OutPaDate

    ){
        boolean insertSuccess = false;

        try {
            ContentValues val = new ContentValues();

            val.put("PatientNumber", PatNo);
            val.put("PatientName", PatName);
            val.put("PatientAddress", PatAddress);
            val.put("PatientDoctor", PatDoctor);
            val.put("PatientPhoneNumber", PatPhoneNo);
            val.put("PatientEmailAddress", PatEmailAddress);
            val.put("AdmissionConsultationTime", InpaTime);
            val.put("AdmissionConsultationDate", InpaDate);
            val.put("DischargeEndConsultationTime", OutPaTime);
            val.put("DischargeEndConsultationDate", OutPaDate);

            db = dbHelper.getWritableDatabase();
            Long res = db.insert (TABLE_NAME, null, val);

            if(res !=  -1)
                insertSuccess = true;

            db.close();
        }catch (Exception e){
            Log.e("Insert Patient Record", "Error: " + e.toString());

        }

        return insertSuccess;
    }
    public static ArrayList<PatientObject> getRows(){
        ArrayList<PatientObject> Patients = new ArrayList<>();
        PatientObject patObj;
        db = dbHelper.getWritableDatabase();
        if (db != null){
            Cursor patCursor = db.query (TABLE_NAME, null, null, null, null, null, null, null);

            while (patCursor.moveToNext()){
                patObj = new PatientObject();
                patObj.setPatientNo(patCursor.getInt(patCursor.getColumnIndex("PatientNumber")));
                patObj.setPatientName(patCursor.getString(patCursor.getColumnIndex("PatientName")));
                patObj.setPatientAddress(patCursor.getString(patCursor.getColumnIndex("PatientAddress")));
                patObj.setPatientDoctor(patCursor.getString(patCursor.getColumnIndex("PatientDoctor")));
                patObj.setPatientPhoneNo(patCursor.getInt(patCursor.getColumnIndex("PatientPhoneNumber")));
                patObj.setPatientEmailAddress(patCursor.getString(patCursor.getColumnIndex("PatientEmailAddress")));
                patObj.setInpatientTime(patCursor.getInt(patCursor.getColumnIndex("AdmissionConsultationTime")));
                patObj.setInpatientDate(patCursor.getInt(patCursor.getColumnIndex("AdmissionConsultationDate")));
                patObj.setOutPatientTime(patCursor.getInt(patCursor.getColumnIndex("DischargeEndConsultationTime")));
                patObj.setOutPatientDate(patCursor.getInt(patCursor.getColumnIndex("DischargeEndConsultationDate")));
                Patients.add(patObj);
            }
            patCursor.close();
        }
        return Patients;
    }
    public static boolean updatePatientRecord(
            int PatNo, String PatName, String PatAddress, String PatDoctor, int PatPhoneNo, String PatEmailAddress,
            int InpaTime, int InpaDate, int OutPaTime, int OutPaDate

    ){
        boolean updateSuccess = false;

        try {
            ContentValues val = new ContentValues();

           // val.put("PatientNumber", PatNo);
            val.put("PatientName", PatName);
            val.put("PatientAddress", PatAddress);
            val.put("PatientDoctor", PatDoctor);
            val.put("PatientPhoneNumber", PatPhoneNo);
            val.put("PatientEmailAddress", PatEmailAddress);
            val.put("AdmissionConsultationTime", InpaTime);
            val.put("AdmissionConsultationDate", InpaDate);
            val.put("DischargeEndConsultationTime", OutPaTime);
            val.put("DischargeEndConsultationDate", OutPaDate);
            String where="PatientNumber = ?";

            db = dbHelper.getWritableDatabase();
            int res = db.update(TABLE_NAME, val, where, new String[]{Integer.toString(PatNo)});
            if(res !=  -1)
                updateSuccess = true;

            db.close();
        }catch (Exception e){
            Log.e("Update Patient Record", "Error: " + e.toString());

        }

        return updateSuccess;
    }
    public static boolean deleteStudentRecord (int PatNo){
        boolean deleteSuccess = false;

        try{
            ContentValues val = new ContentValues();


            String where="PatientNumber = ?";

            db = dbHelper.getWritableDatabase();
            int res = db.delete(TABLE_NAME, where, new String[]{Integer.toString(PatNo)});
            if(res !=  -1);
                deleteSuccess = true;

            db.close();
        }catch (Exception e){
            Log.e("Delete Patient Record", "Error: " + e.toString());

        }

        return deleteSuccess;
    }

}
