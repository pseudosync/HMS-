package com.example.evangelionmedica;

public class PatientObject {
    int PatientNo, PatientPhoneNo, InpatientTime,  InpatientDate,  OutPatientTime,  OutPatientDate;
    String PatientName, PatientAddress, PatientDoctor, PatientEmailAddress;;

    public int getPatientNo() {
        return PatientNo;
    }

    public void setPatientNo(int patientNo) {
        PatientNo = patientNo;
    }

    public int getPatientPhoneNo() {
        return PatientPhoneNo;
    }

    public void setPatientPhoneNo(int patientPhoneNo) {
        PatientPhoneNo = patientPhoneNo;
    }

    public int getInpatientTime() {
        return InpatientTime;
    }

    public void setInpatientTime(int inpatientTime) {
        InpatientTime = inpatientTime;
    }

    public int getInpatientDate() {
        return InpatientDate;
    }

    public void setInpatientDate(int inpatientDate) {
        InpatientDate = inpatientDate;
    }

    public int getOutPatientTime() {
        return OutPatientTime;
    }

    public void setOutPatientTime(int outPatientTime) {
        OutPatientTime = outPatientTime;
    }

    public int getOutPatientDate() {
        return OutPatientDate;
    }

    public void setOutPatientDate(int outPatientDate) {
        OutPatientDate = outPatientDate;
    }

    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String patientName) {
        PatientName = patientName;
    }

    public String getPatientAddress() {
        return PatientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        PatientAddress = patientAddress;
    }

    public String getPatientDoctor() {
        return PatientDoctor;
    }

    public void setPatientDoctor(String patientDoctor) {
        PatientDoctor = patientDoctor;
    }

    public String getPatientEmailAddress() {
        return PatientEmailAddress;
    }

    public void setPatientEmailAddress(String patientEmailAddress) {
        PatientEmailAddress = patientEmailAddress;
    }


}
