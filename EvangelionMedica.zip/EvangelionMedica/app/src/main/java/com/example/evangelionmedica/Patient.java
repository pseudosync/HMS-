package com.example.evangelionmedica;

public class Patient {
}
