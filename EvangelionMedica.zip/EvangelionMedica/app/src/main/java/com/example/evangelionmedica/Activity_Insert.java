package com.example.evangelionmedica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Activity_Insert extends AppCompatActivity {
    EditText PatNo, PatName, PatAddress, PatDoctor, PatPhoneNo, PatEmailAddress, InpaTime,
            InpaDate, OutPaTime, OutPaDate;
    Button btnSave;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__insert);



        PatNo = findViewById(R.id.tvPatientNo);
        PatName = findViewById(R.id.txtPatientName);
        PatAddress = findViewById(R.id.txtPatientAddress);
        PatDoctor = findViewById(R.id.txtPatientDoctor);
        PatPhoneNo = findViewById(R.id.txtPatientPhoneNumber);
        PatEmailAddress = findViewById(R.id.txtPatientEmailAddress);
        InpaTime = findViewById(R.id.InpatientTime);
        InpaDate = findViewById(R.id.InpatientDate);
        OutPaTime = findViewById(R.id.OutPatientTime);
        OutPaDate = findViewById(R.id.OutPatientDate);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {


                if (PatNo.getText().toString().isEmpty() ||
                    PatName.getText().toString().isEmpty() ||
                    PatAddress.getText().toString().isEmpty() ||
                    PatDoctor.getText().toString().isEmpty() ||
                    PatPhoneNo.getText().toString().isEmpty() ||
                    PatEmailAddress.getText().toString().isEmpty() ||
                    InpaTime.getText().toString().isEmpty() ||
                    InpaDate.getText().toString().isEmpty() ||
                    OutPaTime.getText().toString().isEmpty() ||
                    OutPaDate.getText().toString().isEmpty()
                ){
                    if (PatNo.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient ID is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatNo.requestFocus();
                    }else if (PatName.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient Name is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatName.requestFocus();
                    }else if (PatAddress.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient Address is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatAddress.requestFocus();
                    }else if (PatDoctor.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient Doctor is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatDoctor.requestFocus();
                    }else if (PatPhoneNo.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient Phone Number is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatPhoneNo.requestFocus();
                    }else if (PatEmailAddress.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Patient Email Address is REQUIRED!", Toast.LENGTH_LONG).show();
                        PatEmailAddress.requestFocus();
                    }else if (InpaTime.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Time of Admission/Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                        InpaTime.requestFocus();
                    }else if (InpaDate.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Date of Admission/Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                        InpaDate.requestFocus();
                    }else if (OutPaTime.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Time of Discharge/End of Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                        OutPaTime.requestFocus();
                    }else if (OutPaDate.getText().toString().isEmpty()){
                        Toast.makeText(getApplicationContext(),
                                "Date of Discharge/End of Consultation is REQUIRED!", Toast.LENGTH_LONG).show();
                        OutPaDate.requestFocus();
                    }
                }else{
                    int PatientNo = Integer.parseInt(PatNo.getText().toString());
                    String PatientName = PatName.getText().toString();
                    String PatientAddress = PatAddress.getText().toString();
                    String PatientDoctor = PatDoctor.getText().toString();
                    int PatientPhoneNo = Integer.parseInt(PatPhoneNo.getText().toString());
                    String PatientEmailAddress = PatEmailAddress.getText().toString();
                    int InpatientTime = Integer.parseInt(InpaTime.getText().toString());
                    int InpatientDate = Integer.parseInt(InpaDate.getText().toString());
                    int OutpatientTime = Integer.parseInt(OutPaTime.getText().toString());
                    int OutpatientDate = Integer.parseInt(OutPaDate.getText().toString());


                            if (PatientModel.insertPatientRecord (PatientNo, PatientName, PatientAddress, PatientDoctor, PatientPhoneNo, PatientEmailAddress,
                                    InpatientTime, InpatientDate, OutpatientTime, OutpatientDate)){
                                Toast.makeText(getApplicationContext(),
                                        "Patient Record Successfully Inserted", Toast.LENGTH_LONG).show();
                            }

                }
            }catch (Exception e){
                    Log.e("SAVE BUTTON", "Error: " + e.toString());
                }
            }
        });

    }// Oncreate
}// Public Class